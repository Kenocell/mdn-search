console.log('MDN Search Script Injected')
